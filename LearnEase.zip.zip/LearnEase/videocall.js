const domain = "meet.jit.si";

const roomName =
    "LearnEaseClass123";

const options = {

    roomName: roomName,

    width: "100%",

    height: "100%",

    parentNode:
        document.querySelector("#meeting"),

    configOverwrite: {

        prejoinPageEnabled: true

    }

};

const api =
    new JitsiMeetExternalAPI(
        domain,
        options
    );

function goBack() {
    window.history.back();
}