function register(event) {

    event.preventDefault();

    // Get input values
    const fullName =
        document.getElementById("full-name").value.trim();

    const email =
        document.getElementById("email").value.trim().toLowerCase();

    const password =
        document.getElementById("password").value;

    const course =
        document.getElementById("course").value;

    const address =
        document.getElementById("address").value.trim();

    const birthday =
        document.getElementById("birthday").value;

    // Get selected role
    const selectedRole =
        document.querySelector(
            'input[name="role"]:checked'
        );

    // Get selected gender
    const selectedGender =
        document.querySelector(
            'input[name="gender"]:checked'
        );

    // Check required fields
    if (
        fullName === "" ||
        email === "" ||
        password === "" ||
        course === "" ||
        address === "" ||
        birthday === ""
    ) {
        alert("Please fill in all required fields.");
        return;
    }

    // Check role
    if (!selectedRole) {
        alert("Please select your role.");
        return;
    }

    // Check gender
    if (!selectedGender) {
        alert("Please select your gender.");
        return;
    }

    // Check Forbes College email
    if (!email.endsWith("@forbescollege.org")) {
        alert(
            "Please use your Forbes College email (@forbescollege.org)."
        );
        return;
    }

    // Get existing users
    const savedUsers =
        localStorage.getItem("learnEaseUsers");

    let users = [];

    if (savedUsers) {
        users = JSON.parse(savedUsers);
    }

    // Check if email already exists
    const existingUser =
        users.find(function(user) {

            return user.email.toLowerCase() === email;

        });

    if (existingUser) {

        alert(
            "This email is already registered. Please log in."
        );

        return;
    }

    // Create new user
    const newUser = {

        fullName: fullName,

        email: email,

        password: password,

        role: selectedRole.value,

        gender: selectedGender.value,

        course: course,

        address: address,

        birthday: birthday

    };

    // Add user to users array
    users.push(newUser);

    // Save users
    localStorage.setItem(
        "learnEaseUsers",
        JSON.stringify(users)
    );

    // Save current user
    localStorage.setItem(
        "learnEaseCurrentUser",
        JSON.stringify(newUser)
    );

    // Registration successful
    alert(
        "Registration successful! Please log in."
    );

    // Go to login page
    window.location.href = "index.html";
}