function goToDashboard() {

    // Kunin ang email/username
    const username = document.getElementById("username").value.trim();

    // Kunin ang password
    const password = document.getElementById("password").value;


    // CHECK USERNAME
    if (username === "") {

        alert("Please enter your username, email, or ID number.");

        return;
    }


    // CHECK PASSWORD
    if (password === "") {

        alert("Please enter your password.");

        return;
    }


    // Kunin ang registered accounts
    const savedUsers = localStorage.getItem("learnEaseUsers");


    // Kung walang registered account
    if (!savedUsers) {

        alert("No account found. Please register first.");

        return;
    }


    // Convert saved data into an array
    const users = JSON.parse(savedUsers);


    // Hanapin ang account na may matching email at password
    const user = users.find(function(account) {

        return account.email === username &&
               account.password === password;

    });


    // Kung walang matching account
    if (!user) {

        alert("Incorrect email or password.");

        return;
    }


    // I-save ang kasalukuyang naka-login na user
    localStorage.setItem(
        "learnEaseCurrentUser",
        JSON.stringify(user)
    );


    // CHECK ROLE
    if (user.role === "student") {

        window.location.href = "student-dashboard.html";

    }

    else if (user.role === "teacher") {

        window.location.href = "teacher-dashboard.html";

    }

}