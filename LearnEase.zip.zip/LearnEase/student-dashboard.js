/* WELCOME NAME */

let user = localStorage.getItem("learnEaseUser");

if (user) {

    try {

        let userData = JSON.parse(user);

        if (userData.fullName) {

            document.getElementById("studentWelcome").textContent =
                "Welcome back, " + userData.fullName + "!";

        }

    } catch (error) {

        document.getElementById("studentWelcome").textContent =
            "Welcome back, " + user + "!";

    }

}


/* ADD CLASS MODAL */

function openAddClass() {

    document.getElementById("addClassModal").style.display =
        "flex";

}


function closeAddClass() {

    document.getElementById("addClassModal").style.display =
        "none";

}


/* JOIN CLASS */

function joinClass() {

    let classCode =
        document.getElementById("classCode").value.trim();

    let error =
        document.getElementById("classError");


    if (classCode == "") {

        error.textContent =
            "Please enter a class code.";

        return;

    }


    let courses =
        document.getElementById("coursesContainer");


    courses.innerHTML = `
        <div class="course-card">

            <h3>
                ${classCode}
            </h3>

            <p>
                Class joined successfully.
            </p>

        </div>
    `;


    document.getElementById("totalSubjects").textContent =
        "1";


    document.getElementById("classCode").value =
        "";


    error.textContent =
        "";


    closeAddClass();

}


/* CALENDAR */

let currentDate = new Date();


function showCalendar() {

    let year =
        currentDate.getFullYear();


    let month =
        currentDate.getMonth();


    let monthNames = [

        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December"

    ];


    document.getElementById("calendarMonth").textContent =
        monthNames[month] + " " + year;


    let dates =
        document.getElementById("calendarDates");


    dates.innerHTML =
        "";


    let firstDay =
        new Date(year, month, 1).getDay();


    let lastDay =
        new Date(year, month + 1, 0).getDate();


    for (
        let i = 0;
        i < firstDay;
        i++
    ) {

        let emptyDate =
            document.createElement("span");


        dates.appendChild(
            emptyDate
        );

    }


    for (
        let day = 1;
        day <= lastDay;
        day++
    ) {

        let date =
            document.createElement("span");


        date.textContent =
            day;


        let today =
            new Date();


        if (

            day == today.getDate() &&

            month == today.getMonth() &&

            year == today.getFullYear()

        ) {

            date.classList.add(
                "current-day"
            );

        }


        dates.appendChild(
            date
        );

    }

}


/* PREVIOUS MONTH */

document
    .getElementById("previousMonth")
    .addEventListener(
        "click",
        function() {

            currentDate.setMonth(
                currentDate.getMonth() - 1
            );

            showCalendar();

        }
    );


/* NEXT MONTH */

document
    .getElementById("nextMonth")
    .addEventListener(
        "click",
        function() {

            currentDate.setMonth(
                currentDate.getMonth() + 1
            );

            showCalendar();

        }
    );


/* LOAD EVENTS */

function loadEvents() {

    let events =
        JSON.parse(
            localStorage.getItem(
                "learnEaseEvents"
            )
        ) || [];


    let calendarInfo =
        document.getElementById(
            "calendarInfo"
        );


    if (events.length == 0) {

        calendarInfo.innerHTML = `

            <span class="info-dot"></span>

            <div>

                <strong>
                    No events or activities yet.
                </strong>

                <p>
                    Check back later for updates.
                </p>

            </div>

        `;

        return;

    }


    calendarInfo.innerHTML =
        "";


    events.forEach(
        function(event) {

            calendarInfo.innerHTML += `

                <div>

                    <strong>
                        ${event.title}
                    </strong>

                    <p>
                        ${event.date}
                    </p>

                </div>

            `;

        }
    );

}


/* LOAD TO-DO */

function loadTodos() {

    let todos =
        JSON.parse(
            localStorage.getItem(
                "learnEaseTodos"
            )
        ) || [];


    let todoContainer =
        document.getElementById(
            "todoContainer"
        );


    document.getElementById(
        "pendingActivities"
    ).textContent =
        todos.length;


    if (todos.length == 0) {

        document.getElementById(
            "dueSoon"
        ).textContent =
            "0";


        todoContainer.innerHTML = `

            <div class="todo-item">

                <span class="todo-circle">
                </span>

                <div>

                    <strong>
                        No tasks yet
                    </strong>

                    <p>
                        Your activities will appear here.
                    </p>

                </div>

            </div>

        `;

        return;

    }


    todoContainer.innerHTML =
        "";


    todos.forEach(
        function(todo) {

            todoContainer.innerHTML += `

                <div class="todo-item">

                    <span class="todo-circle">
                    </span>

                    <div>

                        <strong>
                            ${todo.title}
                        </strong>

                        <p>
                            Due: ${todo.date}
                        </p>

                    </div>

                </div>

            `;

        }
    );


    let today =
        new Date();


    let dueSoonCount =
        0;


    todos.forEach(
        function(todo) {

            let dueDate =
                new Date(todo.date);


            let difference =
                dueDate - today;


            let days =
                difference /
                (1000 * 60 * 60 * 24);


            if (
                days >= 0 &&
                days <= 3
            ) {

                dueSoonCount++;

            }

        }
    );


    document.getElementById(
        "dueSoon"
    ).textContent =
        dueSoonCount;

}


/* LOAD ANNOUNCEMENTS */

function loadAnnouncements() {

    let announcements =
        JSON.parse(
            localStorage.getItem(
                "learnEaseAnnouncements"
            )
        ) || [];


    let container =
        document.getElementById(
            "announcementContainer"
        );


    if (announcements.length == 0) {

        container.innerHTML = `

            <span class="info-dot"></span>

            <div>

                <strong>
                    No announcements yet.
                </strong>

                <p>
                    Check back later for updates.
                </p>

            </div>

        `;

        return;

    }


    container.innerHTML =
        "";


    announcements.forEach(
        function(announcement) {

            container.innerHTML += `

                <span class="info-dot"></span>

                <div>

                    <strong>
                        ${announcement.text}
                    </strong>

                </div>

            `;

        }
    );

}


/* CLOSE MODAL WHEN CLICKING OUTSIDE */

window.onclick =
    function(event) {

        let modal =
            document.getElementById(
                "addClassModal"
            );


        if (event.target == modal) {

            closeAddClass();

        }

    };


/* RUN */

showCalendar();

loadEvents();

loadTodos();

loadAnnouncements();