/* =========================================
   LEARN EASE - TEACHER DASHBOARD
   ========================================= */


/* =========================================
   GET CURRENT TEACHER
   ========================================= */

function getCurrentTeacher() {

    const userData =
        localStorage.getItem("learnEaseCurrentUser");

    if (userData) {
        return JSON.parse(userData);
    }

    return null;
}


/* =========================================
   TEACHER NAME
   ========================================= */

function loadTeacherName() {

    const welcome =
        document.getElementById("teacherWelcome");

    const user =
        getCurrentTeacher();

    if (!welcome || !user) {
        return;
    }

    if (user.fullName) {

        welcome.textContent =
            "Welcome back, " +
            user.fullName + "!";
    }
}


/* =========================================
   GET TEACHER CLASSES
   ========================================= */

function getTeacherClasses() {

    const savedClasses =
        localStorage.getItem(
            "learnEaseTeacherClasses"
        );

    if (savedClasses) {

        return JSON.parse(savedClasses);
    }

    return [];
}


/* =========================================
   SAVE TEACHER CLASSES
   ========================================= */

function saveTeacherClasses(classes) {

    localStorage.setItem(
        "learnEaseTeacherClasses",
        JSON.stringify(classes)
    );
}


/* =========================================
   DISPLAY CLASSES
   ========================================= */

function displayClasses() {

    const container =
        document.getElementById(
            "classesContainer"
        );

    if (!container) {
        return;
    }


    const classes =
        getTeacherClasses();


    container.innerHTML = "";


    /* =====================================
       NO CLASSES
       ===================================== */

    if (classes.length === 0) {

        container.innerHTML = `

            <div class="no-classes">

                <p>
                    You haven't created any classes yet.
                </p>

                <br>

                <p>
                    Click the + button to create a class.
                </p>

            </div>

        `;

        return;
    }


    /* =====================================
       DISPLAY CLASSES
       ===================================== */

    classes.forEach(function(course, index) {

        const card =
            document.createElement("div");


        card.className =
            "class-card";


        card.innerHTML = `

            <div class="class-info">

                <h3>
                    ${course.subject}
                </h3>

                <p>
                    ${course.program}
                </p>

                <small>
                    Class Code: ${course.code}
                </small>

            </div>


            <div
                class="class-menu"
                onclick="removeClass(${index})"
            >

                <i class="fa-solid fa-ellipsis-vertical"></i>

            </div>

        `;


        container.appendChild(card);

    });
}


/* =========================================
   OPEN CREATE CLASS
   ========================================= */

function openCreateClass() {

    const modal =
        document.getElementById(
            "createClassModal"
        );

    const error =
        document.getElementById(
            "classError"
        );


    if (modal) {

        modal.style.display = "flex";
    }


    if (error) {

        error.textContent = "";
    }
}


/* =========================================
   CLOSE CREATE CLASS
   ========================================= */

function closeCreateClass() {

    const modal =
        document.getElementById(
            "createClassModal"
        );


    if (modal) {

        modal.style.display = "none";
    }
}


/* =========================================
   CREATE CLASS
   ========================================= */

function createClass() {

    const subjectInput =
        document.getElementById(
            "subjectName"
        );

    const programInput =
        document.getElementById(
            "programName"
        );

    const codeInput =
        document.getElementById(
            "classCode"
        );

    const error =
        document.getElementById(
            "classError"
        );


    const subject =
        subjectInput.value.trim();

    const program =
        programInput.value.trim();

    const code =
        codeInput.value
            .trim()
            .toUpperCase();


    /* =====================================
       VALIDATION
       ===================================== */

    if (
        subject === "" ||
        program === "" ||
        code === ""
    ) {

        error.textContent =
            "Please fill in all fields.";

        return;
    }


    /* =====================================
       GET CURRENT TEACHER
       ===================================== */

    const teacher =
        getCurrentTeacher();


    let teacherName =
        "Teacher";


    if (
        teacher &&
        teacher.fullName
    ) {

        teacherName =
            teacher.fullName;
    }


    /* =====================================
       GET EXISTING CLASSES
       ===================================== */

    const classes =
        getTeacherClasses();


    /* =====================================
       CHECK DUPLICATE CODE
       ===================================== */

    const alreadyExists =
        classes.some(
            function(course) {

                return course.code === code;

            }
        );


    if (alreadyExists) {

        error.textContent =
            "This class code already exists.";

        return;
    }


    /* =====================================
       CREATE NEW CLASS
       ===================================== */

    const newClass = {

        subject: subject,

        program: program,

        code: code,

        teacher: teacherName,

        students: [],

        lessons: [],

        activities: [],

        announcements: []

    };


    /* =====================================
       SAVE CLASS
       ===================================== */

    classes.push(
        newClass
    );


    saveTeacherClasses(
        classes
    );


    /* =====================================
       UPDATE DISPLAY
       ===================================== */

    displayClasses();


    /* =====================================
       CLEAR INPUTS
       ===================================== */

    subjectInput.value = "";

    programInput.value = "";

    codeInput.value = "";


    /* =====================================
       CLOSE MODAL
       ===================================== */

    closeCreateClass();


    /* =====================================
       SUCCESS MESSAGE
       ===================================== */

    alert(
        "Class created successfully!"
    );
}


/* =========================================
   REMOVE CLASS
   ========================================= */

function removeClass(index) {

    const classes =
        getTeacherClasses();


    if (
        index < 0 ||
        index >= classes.length
    ) {
        return;
    }


    const confirmRemove =
        confirm(
            "Are you sure you want to remove this class?"
        );


    if (confirmRemove) {

        classes.splice(
            index,
            1
        );


        saveTeacherClasses(
            classes
        );


        displayClasses();
    }
}


/* =========================================
   DISPLAY ANNOUNCEMENTS
   ========================================= */

function displayAnnouncements() {

    const container =
        document.getElementById(
            "announcementsContainer"
        );


    if (!container) {
        return;
    }


    const classes =
        getTeacherClasses();


    let announcements = [];


    classes.forEach(function(course) {

        if (
            course.announcements &&
            Array.isArray(
                course.announcements
            )
        ) {

            course.announcements.forEach(
                function(announcement) {

                    announcements.push({

                        ...announcement,

                        subject:
                            course.subject

                    });

                }
            );
        }

    });


    container.innerHTML = "";


    /* =====================================
       NO ANNOUNCEMENTS
       ===================================== */

    if (announcements.length === 0) {

        container.innerHTML = `

            <div class="no-announcements">

                <p>
                    No announcements yet.
                </p>

            </div>

        `;

        return;
    }


    /* =====================================
       DISPLAY ANNOUNCEMENTS
       ===================================== */

    announcements.forEach(
        function(announcement) {

            const card =
                document.createElement(
                    "div"
                );


            card.className =
                "announcement";


            card.innerHTML = `

                <div class="announcement-content">

                    <h3>
                        ${announcement.title}
                    </h3>

                    <p>
                        ${announcement.message}
                    </p>

                    <small>
                        ${announcement.subject}
                    </small>

                </div>


                <i class="fa-solid fa-bullhorn"></i>

            `;


            container.appendChild(
                card
            );

        }
    );
}


/* =========================================
   CLOSE MODAL WHEN CLICKING OUTSIDE
   ========================================= */

window.addEventListener(
    "click",
    function(event) {

        const modal =
            document.getElementById(
                "createClassModal"
            );


        if (
            modal &&
            event.target === modal
        ) {

            closeCreateClass();
        }

    }
);


/* =========================================
   PAGE LOAD
   ========================================= */

document.addEventListener(
    "DOMContentLoaded",
    function() {

        loadTeacherName();

        displayClasses();

        displayAnnouncements();

    }
);